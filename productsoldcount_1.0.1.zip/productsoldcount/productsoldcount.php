<?php
/**

 * SoldCount

 *

 * NOTICE OF LICENSE

 *

 * This source file is subject to the Open Software License (OSL 3.0)

 * that is bundled with this package in the file LICENSE.txt.

 * It is also available through the world-wide-web at this URL:

 * http://opensource.org/licenses/osl-3.0.php

 *

 * @category  PrestaToolkit

 * @package   ProductSoldCount

 * @author    PrestaToolkit

 * @copyright Copyright 2021 © PrestaToolkit.com All right reserved

 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)

*/

if (!defined('_PS_VERSION_'))
exit;
class ProductSoldCount extends Module
{
	public function __construct()
	{
	$this->name = 'productsoldcount';
	$this->tab = 'front_office_features';
	$this->version = '1.0.1';
	$this->author = 'PrestaToolkit';
	$this->bootstrap = true;
	parent::__construct();
	$this->displayName = $this->l('Product Sold Count');
	$this->description = $this->l('Show number of product sold on product page.');
	}

	public function install()
	{
		return (parent::install() && $this->registerHook('displayProductButtons'));
	}

	public function uninstall()
	{
		return (parent::uninstall());
	}

	public function getContent()
	{
		$html = '';
		if (Tools::isSubmit('submit'.$this->name))
		{
			$html .= '<div class="conf alert alert-success">'.$this->l('Configuration updated').'</div>';
			Configuration::updateValue('PRODUCT_COUNT_SOLD', (int)Tools::getValue('PRODUCT_COUNT_SOLD'));
			Configuration::updateValue('PRODUCT_COUNT_SOLD_TEXT', Tools::getValue('PRODUCT_COUNT_SOLD_TEXT'));
		}
		$html .= '
		<h2>'.$this->displayName.'</h2>';
		$html .= '<div class="panel" style="text-align:center"><a target="_blank" href="https://addons.prestashop.com/en/2_community-developer?contributor=360202"><img src="'.$this->_path.'views/img/banner.jpg"></a></div>';
		$html .= '<div class="panel">
		<form action="'.Tools::safeOutput($_SERVER['REQUEST_URI']).'" method="post" enctype="multipart/form-data">
			<fieldset>	
			<legend>'.$this->l('Settings').'</legend>
			<label class="control-label col-lg-3">'.$this->l('Show for Zero Sold Products?').'</label>
			<div class="col-lg-9">
				<input type="radio" name="PRODUCT_COUNT_SOLD" id="PRODUCT_COUNT_SOLD_1" value="0"
				'.(Configuration::get('PRODUCT_COUNT_SOLD') == '0' || Configuration::get('PRODUCT_COUNT_SOLD') == '' ? "checked='checked'" : '').' />
				 <label class="t" for="PRODUCT_COUNT_SOLD_1">'.$this->l('Yes').'</label>&nbsp;&nbsp;&nbsp;
				 <input type="radio" name="PRODUCT_COUNT_SOLD" id="PRODUCT_COUNT_SOLD_2" value="1"
				 '.(Configuration::get('PRODUCT_COUNT_SOLD') == '1' ? "checked='checked'" : '').' />
				 <label class="t" for="PRODUCT_COUNT_SOLD_2">'.$this->l('No').'</label>
			</div>
			<div class="clear col-lg-12">&nbsp;</div>
			<label class="control-label col-lg-3">'.$this->l('Text to display').'</label>
			<div class="col-lg-9">
				<input type="text" name="PRODUCT_COUNT_SOLD_TEXT" value="'.Configuration::get('PRODUCT_COUNT_SOLD_TEXT').'" />
			</div>
			<div class="clear">&nbsp;</div>
			<center><input type="submit" name="submit'.$this->name.'" value="'.$this->l('Save').'" class="button btn btn-default" /></center>
			</fieldset>
		</form></div>
		';
		return $html;
	}

	public function hookDisplayProductButtons()
	{
		$id_product = (int)Tools::getValue('id_product');
		$total_sales = ProductSale::getNbrSales($id_product);
		if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) {
			$force_ssl = (Configuration::get('PS_SSL_ENABLED') && Configuration::get('PS_SSL_ENABLED_EVERYWHERE'));
			$this->context->smarty->assign(array('base_dir' => _PS_BASE_URL_.__PS_BASE_URI__,
												'base_dir_ssl' => _PS_BASE_URL_SSL_.__PS_BASE_URI__,
												'force_ssl' => $force_ssl));
		}
		$this->context->smarty->assign(array(
			'total_sales' => $total_sales,
			'show_zero' => (int)Configuration::get('PRODUCT_COUNT_SOLD'),
			'product_count_text' => (string)Configuration::get('PRODUCT_COUNT_SOLD_TEXT')
		));
		return $this->display(__FILE__, 'hook.tpl');
	}
}